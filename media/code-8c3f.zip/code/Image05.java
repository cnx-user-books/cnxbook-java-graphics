/*File Image05.java
Copyright 1997, R.G.Baldwin

This program illustrates image manipulation by removing
the red color from all the pixels in an image and also
making the image partially transparent.

The program requires access to an image file named
"logomain.gif" in the current directory on the hard disk.

Just about any image should do, but it needs to be big
enough that you can see it when it is displayed at 
its normal size and should be small enough to fit on the
screen.

If the program is unable to load the image file within ten
seconds, it will abort with an error message.  

A large portion of the code in this program has been
illustrated in previous lessons and won't be discussed 
in this lesson.  The following discussion involves mainly 
material that has not been covered in a previous lesson.

This program reads an image file from the disk and saves
it in memory under the name rawImage.  

Then it declares an array of int of sufficient size to
contain one int value for every pixel in the image. The
name of the array is pix.

Then it instantiates an object of type PixelGrabber which
associates the rawImage with the array of int.  

Following this, it invokes the grabPixels() method on the 
object of type PixelGrabber to cause the pixels in the 
rawImage to be converted to int values and stored in the 
array named pix.

Then it uses bitwise operators to mask the red byte out of
every pixel value and to make the image partially 
transparent by masking the alpha byte with the hex value
C0 (an alpha value of 00 is completely transparent, and an
alpha value of FF is completely opaque).

Then it uses the createImage() method of the Component
class along with the constructor for the MemoryImageSource
to create a new image from the modified pixel data.  The
name of the new image is modImage.
    
Finally, it overrides the paint() method where it uses
the drawImage() method to display both the raw image and
the modified image on the same Frame object.  The colors
in the modified image reflect the lack of red.  

Also the modified image is partially transparent, allowing
the yellow background to show through on many pixels.  

On a Win95 system. transparency seems to be accomplished 
by causing a regular distribution of pixels to be rendered
in the background color.  The higher the degree of
transparency, the larger the percentage of pixels that are
rendered in the background color.
        
This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;

class Image05 extends Frame{ //controlling class
  Image rawImage;//ref to raw image file fetched from disk
  int rawWidth;
  int rawHeight;

  Image modImage; //ref to modified image
  
  //Inset values for the container object
  int inTop;
  int inLeft;
  
  //=====================================================//

  public static void main(String[] args){
    Image05 obj = new Image05();//instantiate this object
      obj.repaint();//render the image
   }//end main

  //=====================================================//
  
  public Image05(){//constructor
    //Get an image from the specified file in the current
    // directory on the local hard disk.
    rawImage = 
      Toolkit.getDefaultToolkit().getImage("logomain.gif");
 
    //Use a MediaTracker object to block until the image
    // is loaded or ten seconds has elapsed.
    MediaTracker tracker = new MediaTracker(this);
    tracker.addImage(rawImage,1);
        
    try{ //because waitForID throws InterruptedException
      if(!tracker.waitForID(1,10000)){
        System.out.println("Load error.");
        System.exit(1);        
      }//end if
    }catch(InterruptedException e){System.out.println(e);}
    
    //Raw image has been loaded.  Establish width and 
    // height of the raw image.
    rawWidth = rawImage.getWidth(this);
    rawHeight = rawImage.getHeight(this);

    this.setVisible(true);//make the Frame visible
    
    //Get and store inset data for the Frame object so 
    // that it can be easily avoided.
    inTop = this.getInsets().top;
    inLeft = this.getInsets().left;
    
    
    //Use the insets and the size of the raw image to
    // establish the overall size of the Frame object.
    // Make the Frame object twice the height of the
    // image so that the raw image and the modified image
    // can both be rendered on the Frame object.
    this.setSize(inLeft+rawWidth,inTop+2*rawHeight);
    this.setTitle("Copyright 1997, Baldwin");
    this.setBackground(Color.yellow);
    
    //Declare an array object to receive the pixel 
    // representation of the image
    int[] pix = new int[rawWidth * rawHeight];

    //Convert the rawImage to numeric pixel representation
    try{//because grapPixels() throws InterruptedException
      //Instantiate a PixelGrabber object specifying
      // pix as the array in which to put the numeric 
      // pixel data. See JDK 1.1.3 docs for parameters
      PixelGrabber pgObj = new PixelGrabber(
                          rawImage,0,0,rawWidth,rawHeight,
                                           pix,0,rawWidth);
	    
      //Invoke the grabPixels() method on the PixelGrabber
      // object to actually convert the image to an array 
      // of numeric pixel data stored in pix. Also test 
      // for success in the process.
      if(pgObj.grabPixels() && ((pgObj.getStatus() & 
                            ImageObserver.ALLBITS) != 0)){
        //Mask the red byte out of every pixel by ANDing
        // the red byte with 00.  Also make partially
        // transparent by ANDing the alpha byte with C0 
        for(int cnt = 0; cnt < (rawWidth*rawHeight);cnt++){
          pix[cnt] = pix[cnt] & 0xC000FFFF;
        }//end for loop
      }//end if statement
      else System.out.println("Pixel grab not successful");
    }catch(InterruptedException e){System.out.println(e);}
    
    //Use the createImage() method to create a new image 
    // from the array of pixel values.
    modImage = this.createImage(
                   new MemoryImageSource(
                       rawWidth,rawHeight,pix,0,rawWidth));
    
    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor  
//=======================================================//
  
  //Override the paint method to display both the rawImage
  // and the modImage on the same Frame object.
  public void paint(Graphics g){
    if(modImage != null){
      g.drawImage(rawImage,inLeft,inTop,this);
      g.drawImage(modImage,inLeft,inTop+rawHeight,this);
    }//end if
  }//end paint()
}//end Image05 class
//=======================================================//