/*File Graphics08.java
Copyright 1997, R.G.Baldwin

This program illustrates the drawing of text using methods
primarily of the Graphics, Font, and FontMetrics classes.

A variety of methods are illustrated along with a variety
of font types, styles, sizes, and colors.

The list of available fonts reported by getFontList() was

Dialog
SansSerif
Serif
Monospaced
Helvetica
TimesRoman
Courier
DialogInput
ZapfDingbats

According to John Zukowski in "Java AWT Reference":
  
"The ZapfDingbats font name has been dropped completely
because the characters in this font have official Unicode
mappings in the range \u2700 to \u27ff."

The name still appears on my system as of JDK 1.1.3.
However, an attempt to draw the name in the ZapfDingbats
font resulted in a series of rectangular boxes being drawn,
one for each character in the name.  Therefore, no attempt
was made to demonstrate the font associated with this name
in this program.  

This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Graphics08 extends Frame{ //controlling class
  //Override the paint method
  public void paint(Graphics g){
    g.setColor(Color.red);//set the drawing color to red
    
    //Translate the 0,0 coordinate of the graphics context
    // to the upper left-hand corner of the client area of
    // the Frame object.
    g.translate(
               this.getInsets().left,this.getInsets().top);

    //Get list of fonts on the system
    String[] fonts = 
                 Toolkit.getDefaultToolkit().getFontList();
      
    //Set the font to the fifth one in the list.  Set the
    // style to BOLD.  Set the size to 20-point.
    g.setFont(new Font(fonts[4],Font.BOLD,20));
    
    //Get the height attribute for the selected font
    int height = g.getFontMetrics().getHeight();
    
    //Set the initial y coordinate using the height 
    // attribute.
    int y = height; 
         
    //Display a title using the selected font at the 
    // specified y-coordinate in red.  Center the title 
    // around an x-ccordinate value of 200 pixels.
    String msg = "The list of available fonts follows:";
    g.drawString(
      msg,200 - (g.getFontMetrics().stringWidth(msg))/2,y);

    //Set drawing color to green
    g.setColor(Color.green);

    //Display the list of available fonts in green except 
    // don't try to display ZapfDingbats because it is 
    // used to represent characters beyond the first 256.
    // Display the name of each font in the font that
    // matches the name.  Center around a value of 200
    // pixels.  Increase the size of the font for each
    // line of output by adding the loop count to a base
    // size of 17 points.  Adjust the vertical spacing
    // between lines of output appropriately as the size
    // of the font increases. Set the style to BOLD ITALIC.
    for(int cnt = 0; cnt < fonts.length-1; cnt++){
      g.setFont(new Font(fonts[cnt],
                          Font.BOLD | Font.ITALIC,17+cnt));
      height = g.getFontMetrics().getHeight();
      g.drawString(fonts[cnt],
        200-(g.getFontMetrics().stringWidth(fonts[cnt]))/2,
                                                y+=height);
    }//end for loop

    //Set drawing color to blue
    g.setColor(Color.blue);

    //Set the font to the first one in the list of fonts.
    // Set the style to PLAIN.  Make it 17-point size.
    g.setFont(new Font(fonts[0],Font.PLAIN,17));
    height = g.getFontMetrics().getHeight();    
    
    //Display another title
    y += height;
    g.drawString(
      "INFORMATION ABOUT THE SELECTED FONT FOLLOWS: ",5,y);
      
    //Display information about the current font      
    y += height;
    g.drawString("" + g.getFont(),5,y);
    
    //Display another title
    y += 2*height;
    g.drawString(
                "PART OF THE AUTHOR'S NAME FOLLOWS: ",5,y);
    
    //Create a character array and display part of it    
    char myData[] = 
        {'D','i','c','k',' ','B','a','l','d','w','i','n',};
    y += height;
    //Display the data in the array, skipping the first 
    // and last characters in the array
    g.drawChars(myData,1,10,5,y);
      
  }//end paint()

  public Graphics08(){//constructor
    this.setTitle(
             "Shape Samples,Copyright 1997, R.G.Baldwin");
    this.setSize(500,400);
    this.setVisible(true);

    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor
  
  public static void main(String[] args){
    new Graphics08();//instantiate this object
  }//end main
}//end Graphics08 class
//=======================================================//
