/*File Image01.java
Copyright 1997, R.G.Baldwin

This program illustrates the fetch and display of an
image without using MediaTracker to make the process
smoother.

In doing so, it also illustrates:

Use of the Toolkit class and the getImage() method to read
an image file from the local hard disk.

Use of the drawImage() method to display a loaded image
onto a Frame object.

Use of the getWidth() and getHeight() methods to determine
the size of the image for drawing purposes.

Use of the translate() method to eliminate the coordinate
offset caused by the insets of a Frame object.

Use of an anonymous inner-class to service the "close" 
button on a Frame object.
    
This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Image01 extends Frame{ //controlling class
  Image image; //reference to an Image object
  
  public Image01(){//constructor
    this.setTitle("Copyright 1997, R.G.Baldwin");
    this.setSize(350,200);
    
    //Get an image from the specified file in the current
    // directory on the local hard disk.
    image = 
      Toolkit.getDefaultToolkit().getImage("logomain.gif");
    
    //Make the Frame object visible.  Note that the image
    // is not visible on the Frame object when it first
    // appears on the screen.
    this.setVisible(true);

    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor  
//=======================================================//
  
  //Override the paint method
  public void paint(Graphics g){
    //Translate origin to avoid insets.
    g.translate(
               this.getInsets().left,this.getInsets().top);
    
    //Now draw it half its normal size.
    g.drawImage(image,0,0,image.getWidth(this)/2,
                            image.getHeight(this)/2,this);
                            
//    this.repaint();//may be superfluous                            
  }//end paint()
//=======================================================//
  public static void main(String[] args){
    new Image01();//instantiate this object
  }//end main
}//end Image01 class
//=======================================================//