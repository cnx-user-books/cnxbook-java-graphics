/*File Image02.java
Copyright 1997, R.G.Baldwin

This program illustrates the fetch and display of an
image.

In doing so, it also illustrates:

Use of the Toolkit class and the getImage() method to read
an image file from the local hard disk.

Use of a MediaTracker object to monitor the loading of
an image file from the local hard disk and block the 
thread until the image is loaded.

Use of the drawImage() method to display a loaded image
onto a Frame object.

Use of the getWidth() and getHeight() methods to determine
the size of the image for drawing purposes.

Use of the translate() method to eliminate the coordinate
offset caused by the insets of a Frame object.

Use of an anonymous inner-class to service the "close" 
button on a Frame object.
    
This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Image02 extends Frame{ //controlling class
  Image image; //reference to an Image object
  
  public Image02(){//constructor
    this.setTitle("Copyright 1997, R.G.Baldwin");
    this.setSize(350,200);
    
    //Get an image from the specified file in the current
    // directory on the local hard disk.
    image = 
      Toolkit.getDefaultToolkit().getImage("logomain.gif");
    
    //Make the Frame object visible.  Note that the image
    // is not visible on the Frame object when it first
    // appears on the screen.
    this.setVisible(true);

    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor  
//=======================================================//
  
  //Override the paint method
  public void paint(Graphics g){
    //Translate origin to avoid insets.
    g.translate(
               this.getInsets().left,this.getInsets().top);
    
    //Use a MediaTracker object to block until the image
    // is fully loaded before attempting to draw it on the 
    // screen. If the image fails to load successfully
    // within one second, terminate the program.  Without 
    // the use of the MediaTracker object, the display of 
    // the image is very choppy while it is being loaded 
    // for the particular image being used.  A smaller
    // image may load and display more smoothly without
    // use of MediaTracker.
    MediaTracker tracker = new MediaTracker(this);
    tracker.addImage(image,1);//add image to tracker list
    try{
      //Block for up to one second while trying to load
      // the image. A larger image may require more time.
      if(!tracker.waitForID(1,5000)){//increased to five seconds
	        System.out.println("Failed to load image");
	        System.exit(0);
        }//end if
    }catch(InterruptedException e){System.out.println(e);}
    
    //Now draw it half its normal size.
    g.drawImage(image,0,0,image.getWidth(this)/2,
                            image.getHeight(this)/2,this);
  }//end paint()
//=======================================================//
  public static void main(String[] args){
    new Image02();//instantiate this object
  }//end main
}//end Image02 class
//=======================================================//