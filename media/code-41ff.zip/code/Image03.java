/*File Image03.java
Copyright 1997, R.G.Baldwin

This program illustrates the use of the getScaledInstance()
method of the Image class.

The program invokes the getImage() method on an object of
the Toolkit class to associate an Image reference named
rawImage to an image file on the local hard disk.

Then the program invokes the getScaledInstance() method
on the rawImage object five times in succession to produce
five new scaled instances of the image.  A different
scaling algorithm is implemented for each of the new
scaled instances of the image.

A MediaTracker object is instantiated in the overridden
paint() method.  The rawImage object as well as the five
new scaled instances are added to the list being tracked
by the MediaTracker object.  All are added with the same
identifier (same priority).
    
The waitForAll() method of the MediaTracker class is used 
to block the thread until all six of the image objects are
loaded and properly scaled.  A noticible pause of about
4 or 5 seconds occurs at this point using JDK 1.1.3 under
Win95 with a 133mhz Pentium processor.

All five scaled images are then drawn on the screen.  There
are no obvious pauses at this point.  All five images
appear on the screen almost simultaneously.

In an earlier program written by this author, but not
included in the lesson, when a version of the drawImage()
method that scales while drawing the images was used,
and several scaled versions of the image were drawn,
there was a noticible progression from the first to the
last image as they were being drawn on the screen.

Thus, the tradeoff is to incur the earlier pause in order
to achieve very fast drawing of the scaled images.
      
This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Image03 extends Frame{ //controlling class
  //references to Image objects
  Image rawImage,image1,image2,image3,image4,image5; 
  
  public Image03(){//constructor
    this.setTitle("Copyright 1997, R.G.Baldwin");
    this.setSize(300,500);
    
    //Get an image from the specified file in the current
    // directory on the local hard disk.
    rawImage = 
      Toolkit.getDefaultToolkit().getImage("logomain.gif");
    
    //Create five scaled instances of the image using each
    // of the five different scaling algorithms
    image1 = rawImage.getScaledInstance(
                         200,-1,Image.SCALE_AREA_AVERAGING);
    image2 = rawImage.getScaledInstance(
                         200,-1,Image.SCALE_DEFAULT);
    image3 = rawImage.getScaledInstance(
                         200,-1,Image.SCALE_FAST);
    image4 = rawImage.getScaledInstance(
                         200,-1,Image.SCALE_REPLICATE);
    image5 = rawImage.getScaledInstance(
                         200,-1,Image.SCALE_SMOOTH);
    
    //Make the Frame object visible.  Note that the image
    // is not visible on the Frame object when it first
    // appears on the screen.
    this.setVisible(true);

    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor  
//=======================================================//
  
  //Override the paint method
  public void paint(Graphics g){
    //Translate origin to avoid insets.
    g.translate(
               this.getInsets().left,this.getInsets().top);
    
    //Use a MediaTracker object to block until all images
    // are scaled and loaded before attempting to draw 
    // them. Instantiate the object and add all five
    // scaled images to the list. 
    MediaTracker tracker = new MediaTracker(this);
    //Add images to the tracker list
    tracker.addImage(rawImage,1);
    tracker.addImage(image1,1);
    tracker.addImage(image2,1);
    tracker.addImage(image3,1);
    tracker.addImage(image4,1);
    tracker.addImage(image5,1);
    
    try{
      //Block until all images on the list are scaled and
      // loaded.  There is a noticible pause of 4 or 5 
      // seconds at this point using JDK 1.1.3 under Win95 
      // with a 133mhz Pentium processor.
      tracker.waitForAll();
    }catch(InterruptedException e){System.out.println(e);}
    
    //Now test for errors and draw all five images if no
    // errors were detected.  All five images appear
    // on the screen almost simultaneously.
    if(!tracker.isErrorAny()){
	    g.drawImage(image1,0,0,this);
	    g.drawImage(image2,0,80,this);
	    g.drawImage(image3,0,160,this);
	    g.drawImage(image4,0,240,this);
	    g.drawImage(image5,0,320,this);
    }//end if
    else{
      System.out.println("Load error");  
      System.exit(1);
    }//end else
  }//end paint()
//=======================================================//
  public static void main(String[] args){
    new Image03();//instantiate this object
  }//end main
}//end Image03 class
//=======================================================//