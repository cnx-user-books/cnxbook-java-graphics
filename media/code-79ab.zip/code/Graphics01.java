/*File Graphics01.java
Copyright 1997, R.G.Baldwin
Illustrates obtaining and using a graphics context. The
drawString() method is invoked on the graphics context of
a Frame object to display the string "Hello World".

When you compile and run this program, a Frame object will
appear on the screen.  The client area of the Frame
object will display the words Hello World.

When you press the close button on the Frame object, the
program will terminate and control will be returend to the
operating system.

This program was tested using JDK 1.1.3 under Win95.
**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Graphics01 extends Frame{ //controlling class

  //Override the paint method to display the string "Hello
  // World" on the graphics context of the Frame object.
  public void paint(Graphics g){
    g.drawString("Hello World",100,40);
  }//end paint()

  public Graphics01(){//constructor
    this.setTitle("Copyright 1997, R.G.Baldwin");
    this.setSize(350,50);
    this.setVisible(true);

    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor
  
  public static void main(String[] args){
    new Graphics01();//instantiate this object
  }//end main
}//end Graphics01 class
//=======================================================//