/*File Graphics06.java
Copyright 1997, R.G.Baldwin

Illustrates the use of setXORMode() and setPaintMode().
Shows the result of overlapping drawings in both modes.
Also shows the result of redrawing a figure that was
originally drawn in XOR mode.

It is strongly recomended that you compile and run this
program because you will probably need to see the display
to understand the following description.

This program draws two sets of four overlapping filled 
squares at different locations on the screen with a drawing
color of red.  The current drawing color is not changed
during the entire sequence of drawing squares.

The first two overlapping squares are drawn in the default
Paint mode.  This produces two red squares which overlap
and merge together in the overlapping area.  Except
for the fact that you know they are squares, it is
not possible to discern the shape of the overlapping area.

Then the mode is changed to XOR with an XOR color of green
and a third overlapping square is drawn with the current
drawing color being red.

In this case, the overlap between the two squares is green.
Thus, it is possible to discern the shape of of the 
overlapping area.

In addition, that portion of the square that doesn't 
overlap the red square but is drawn on the white background
is rendered in blue.  An attempt will be made to explain 
this in the text of the lesson.

Then the mode is reset to the default of Paint and a fourth
overlapping square is drawn.  It simply overdraws the blue
square with red in the intersecting area.

To demonstrate the manner in which drawing the same figure
twice in the XOR mode causes it to be erased, the same
sequence is repeated again further to the right on the
screen.  However, in this case, after all four squares
have been drawn, the mode is set to XOR and another square
is drawn in the exact location of the third square in the
sequence.  In other words, the third square is redrawn in
XOR mode.  This causes the green and blue portions of that
square to be replaced by red and white, effectively erasing
the square and returning the display to its original form.
However, that portion of the third square that overlaps
the fourth square, was rendered as green because the
fourth square wasn't there when the third square was
originally drawn.  Therefore, redrawing it causes the
redrawn square to overlap the fourth square and produce
the green overlap area.


This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Graphics06 extends Frame{ //controlling class
  //Override the paint method
  public void paint(Graphics g){
    g.setColor(Color.red);
    
    //Translate the 0,0 coordinate of the graphics context
    // to the upper left-hand corner of the client area of
    // the Frame object.
    g.translate(
               this.getInsets().left,this.getInsets().top);
    
    //Draw first set of four overlapping filled red 
    // squares.  Start drawing in the default Paint mode.
    g.fillRect(0,0,50,50);
    g.fillRect(25,25,50,50);
    //Set to XOR mode and draw another overlapping square
    // with the drawing color set to red and the XOR color
    // set to green.  This will produce a square that is 
    // green where it overlaps a red square and is blue
    // where it doesn't overlap the red square but is
    // being drawn on the white background.
    g.setXORMode(Color.green);
    g.fillRect(50,50,50,50);
    //Reset to default Paint mode and draw another 
    // overlapping square. This will simply draw a red
    // square covering part of the blue square and covering
    // the white background
    g.setPaintMode();
    g.fillRect(75,75,50,50);
    
    //Now demonstrate the cancelling effect of redrawing
    // a square in XOR mode.
    //Draw second set of four overlapping filled red 
    // squares exactly as before but at a different 
    // location on the screen.
    g.fillRect(200,0,50,50);
    g.fillRect(225,25,50,50);
    g.setXORMode(Color.green);
    g.fillRect(250,50,50,50);
    g.setPaintMode();
    g.fillRect(275,75,50,50);
    //Now redraw the third square in the second set
    // in XOR mode.  This will erase the one originally
    // drawn except where it overlaps the fourth square.
    // That overlap will be green.
    g.setXORMode(Color.green);
    g.fillRect(250,50,50,50);

  }//end paint()

  public Graphics06(){//constructor
    this.setTitle("Copyright 1997, R.G.Baldwin");
    this.setSize(350,200);
    this.setVisible(true);

    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor
  
  public static void main(String[] args){
    new Graphics06();//instantiate this object
  }//end main
}//end Graphics06 class
//=======================================================//
