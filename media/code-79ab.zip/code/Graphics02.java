/*File Graphics02.java
Copyright 1997, R.G.Baldwin

Illustrates use of copyArea() and clearRect() methods of
the Graphics class.

This program draws the string "Hello World" in the upper
left corner of a Frame object.  Then it uses the 
copyArea() method to make two additional copies of the 
drawing by copying a rectangular area from the upper left 
corner to two other areas.

Then it uses the clearRect() method to erase most of
the letter "H" from the second copy by clearing a 
rectangular portion of the screen that contains part of 
the drawing of the letter "H".

When you compile and run this program, a Frame object will
appear on the screen.  The client area of the Frame
object will display the words Hello World in two different
places, and the same words with part of the "H" missing
in one other place.

When you press the close button on the Frame object, the
program will terminate and control will be returend to the
operating system.

This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Graphics02 extends Frame{ //controlling class

  //Override the paint method to display the string "Hello
  // World" on the graphics context of the Frame object.
  public void paint(Graphics g){
    g.drawString("Hello World",10,40);//draw the string
    g.copyArea(0,0,100,100,100,0); //copy to another spot
    g.copyArea(0,0,100,100,100,50); //copy to another spot    
    g.clearRect(100,50,15,50); //erase part of second copy
  }//end paint()

  public Graphics02(){//constructor
    this.setTitle("Copyright 1997, R.G.Baldwin");
    this.setSize(350,150);
    this.setVisible(true);

    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor
  
  public static void main(String[] args){
    new Graphics02();//instantiate this object
  }//end main
}//end Graphics02 class
//=======================================================//