/*File Graphics05.java
Copyright 1997, R.G.Baldwin

This program replicates the functionality of the program
named Graphics03.  However, it eliminates the problem of
insets by invoking the translate() method on the original
graphics context to shift the origin to the upper left-
hand corner of the the client area of the Frame object 
(inside the borders).

This example program is heavily based on an applet from the
book entitled AWT Reference by John Zukowski which was
designed to explain the use of clipping in Java.  It was
modified to include insets, translate(), color, etc.

The program illustrates the following graphics concepts:
  
1. Creation of a second reference to a graphics context.

2. The use of the translate() method to shift the 0,0
coordinate position to a different spot on the graphics
context.

3. The use of clipping.

4. The use of setColor() to change the current drawing 
color.

5. The use of the dispose() method to return graphics
context resources to the operating system.

The paint method in an extended Frame class is overridden 
to perform the following tasks.

Use the inset values with the translate() method to move
the 0,0 coordinate to the upper left-hand corner of the
client area of the Frame object.

Set the drawing color to red.

Create a second reference to the graphics context passed
in to the paint() method.
    
Use the second reference to draw a red square 100 pixels on
each side.
    
Set the drawing color for the second reference to blue.

Clip the drawing area for the second reference to a square
50 pixels on each side centered in the original square.
    
Use the second reference to attempt to draw a blue line
from the upper left-hand corner to the lower right-hand
corner of the original rectangle.  Only that portion
inside the new clipped drawing area will be drawn.
    
Call the dispose() method to return the resources occupied
by the second reference to the operating system.  Then set
the reference to null so that it will become eligible for
garbage collection.

Use the original graphics context to set the drawing color
to green.

Use the original graphics context to draw a green line
from the lower left-hand corner to the upper right-hand
corner of the original red rectangle.  This entire line
will be visible because the clipping area does not apply 
to the original graphics context.
    
When you compile and run this program, a Frame object will
appear on the screen.  A red square will appear in the
upper left portion of the client area.  A green line will
run from bottom left to upper right within the square.  A 
segment of a blue line will appear as the center portion 
of an imaginary line that runs from top left to lower 
right within the square.

When you press the close button on the Frame object, the
program will terminate and control will be returend to the
operating system.

This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Graphics05 extends Frame{ //controlling class
  //Override the paint method
  public void paint(Graphics g){
    g.setColor(Color.red);
    
    //Translate the 0,0 coordinate of the graphics context
    // to the upper left-hand corner of the client area of
    // the Frame object.
    g.translate(
               this.getInsets().left,this.getInsets().top);
    
    //Create another reference to the Graphics context g
    Graphics clpArea = g.create();
    
    //Use original clpArea reference to draw a 
    // red rectangle
    clpArea.drawRect(0,0,100,100);
    clpArea.setColor(Color.blue);
    
    //Reduce clpArea reference to rectangle shown
    clpArea.clipRect(25,25,50,50);
    
    //Use clpArea ref to try to draw a blue diagonal line
    // across the entire original rectangle.  Only middle
    // portion actually gets drawn.
    clpArea.drawLine(0,0,100,100);
    
    clpArea.dispose();//free system resources
    clpArea = null;//make eligible for garbage collection
    g.setColor(Color.green);
    
    //Use the original graphics context to draw a green
    // diagonal line across the entire rectangle.
    g.drawLine(0,100,100,0);
  }//end paint()

  public Graphics05(){//constructor
    this.setTitle("Copyright 1997, R.G.Baldwin");
    this.setSize(300,150);
    this.setVisible(true);

    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor
  
  public static void main(String[] args){
    new Graphics05();//instantiate this object
  }//end main
}//end Graphics05 class
//=======================================================//
