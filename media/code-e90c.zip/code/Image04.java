/*File Image04.java
Copyright 1997, R.G.Baldwin

This program illustrates animation with or without double 
buffering. It requires access to an image file named
"logomain.gif" in the current directory on the hard disk.

Just about any image should do, but it needs to be big
enough that you can see it when it is displayed at 
its normal size..  

You should be able to find hundreds of gif or jpg files in 
the cache directory of your browser.  You will need to 
rename the file as above and copy it into the current 
directory on your hard disk.

If the program is unable to load the image file within ten
seconds, it will abort with an error message.  If the file
is large, or is being loaded from a web server, it may be 
necessary to increase the timeout interval.

To run the program in double-buffer mode, enter the
following at the command line:
  
java image04

To run the program without double buffering, enter the
following at the command line:
  
java image04 x

Providing any command-line argument disables double-buffer
mode and causes the program to draw directly to the screen.

The program will continue to animate the image until you
press the close button on the Frame object.    

This program causes a series of images of increasing and
decreasing size to be scaled and rendered on the screen.

The series of images are scaled in such a way as to make
it appear that the base image is moving into and out of
the screen like a yo-yo.  The image is pinned at its 
upper left-hand corner.

Scaling is performed as the image is being drawn either
onto the screen or into the buffer area. (Prescaled images
are not used.)  Such scaling is performed in the paint()
method.  

The paint() method is invoked approximately 20 times per 
second which is sufficiently fast to provide a good
illusion of animation.

The screen image is modified once each time that the 
paint() method is invoked.

When in double-buffer mode, the contents of the buffer are 
are transferred to the screen upon entry into the paint()
method.  Then the next version of the image is drawn into 
the buffer area and the paint() method exits.

When not in double-buffer mode, the image is drawn directly
to the screen upon entry into the paint() method and then
the paint() method exits.

The update() method is overridden to eliminate unnecessary
erasing of the screen and the flashing that this often
causes.  As a result, each time paint() is entered (when
not in double-buffer mode) it is necessary to erase a small
area of the screen in order to eliminate any residue from
the previous image.  (The update() method normally erases
the entire screen each time repaint() is invoked and then
invokes the paint() method.)

It is not necessary to erase the screen in double-buffer 
mode because an entire screen image is copied from the 
buffer area to the screen each time the paint() method is
invoked. However, it is necessary to erase a small portion 
of the buffer area each time before drawing a new image 
in it.

There is a lot of flicker and the animation illusion isn't 
very good when not in double-buffer mode. This flicker is
apparently the result of drawing each successive image in
view of the viewer.  In other words, even though it happens
very quickly, the viewer can still see each image being
drawn on the screen.

The flicker is eliminated in double-buffer mode and the 
illusion is pretty good.  In this case, the actual drawing
of the individual images takes place out of sight of the
viewer, and once drawn, the entire image is blasted to 
the screen very quickly.

Be aware, however, that even in double-buffer mode, the 
scaling of the images may be much less than perfect and 
you may see some fuzz growing on your image as it 
changes in size from large to small and back again. This is 
because the pixel representation of the image is not
particularly good at any size, and the pixel 
representation at one size is different from the pixel 
representation at a slightly different size.  This is
especially noticible in areas with a high degree of detail
such as in areas containing text.

The animation is performed in a Frame object as the
container. The size of the Frame is automatically adjusted 
to accommodate the size of the image.
      
This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Image04 extends Frame{ //controlling class
  Image rawImage;//ref to raw image file fetched from disk
  int rawWidth;
  int rawHeight;
  
  //Width and height values for a particular 
  // animation frame 
  int newWidth;
  int newHeight;
  
  //Inset values for the container object
  int inTop;
  int inLeft;
  
  //References to objects used for double buffering
  Image offScreenImage;
  Graphics offScreenContext;
  
  //To double buffer or not double buffer
  boolean doubleBuf = true;

  //=====================================================//

  public static void main(String[] args){
    Image04 obj = new Image04();//instantiate this object
    
    //Declare some local variables
    double delta = 0;
    double scale = 0;
    
    //Set for double buffering or not based on command-
    // line args.  Default is double buffering.  Enter any
    // command-line argument to disable double buffering.
    if(args.length == 0){
      obj.doubleBuf = true;
      System.out.println("Double buffer mode");
    }//end if
    else{
      obj.doubleBuf = false;
      System.out.println("Not double buffer mode");
    }//end else
    
    //Loop in animated mode until close button is clicked
    while(true){
      //Reverse direction of motion if necessary
      if(scale >= 0.999) delta = -0.005;//move into screen
      if(scale <= 0.015) delta = 0.005;//move out of screen
      
      //Establish width and height for this rendering
      // of the image.
      obj.newWidth = (int)(scale*obj.rawWidth);
      obj.newHeight = (int)(scale*obj.rawHeight);      
      obj.repaint();//render the image
      
      scale += delta;//update scale for next rendering

      //Sleep for awhile. Animate at approximately 20
      // frames per second.
      try{
        Thread.currentThread().sleep(50);      
      }catch(InterruptedException e){System.out.println(e);}
    }//end while loop
   }//end main

  //=====================================================//
  
  public Image04(){//constructor
    //Get an image from the specified file in the current
    // directory on the local hard disk.
    rawImage = 
      Toolkit.getDefaultToolkit().getImage("logomain.gif");
 
    //Use a MediaTracker object to block until the image
    // is loaded or ten seconds has elapsed.
    MediaTracker tracker = new MediaTracker(this);
    tracker.addImage(rawImage,1);
        
    try{
      if(!tracker.waitForID(1,10000)){
        System.out.println("Load error.");
        System.exit(1);        
      }//end if
    }catch(InterruptedException e){System.out.println(e);}
    
    //Raw image has been loaded.  Establish width and 
    // height of the raw image.
    rawWidth = rawImage.getWidth(this);
    rawHeight = rawImage.getHeight(this);

    this.setVisible(true);//make the Frame visible
    
    //Get and store inset data for the Frame object so 
    // that it can be easily avoided.
    inTop = this.getInsets().top;
    inLeft = this.getInsets().left;
    
    //Use the insets and the size of the raw image to
    // establish the overall size of the Frame object.
    this.setSize(inLeft+rawWidth,inTop+rawHeight);
    this.setTitle("Copyright 1997, Baldwin");
    this.setBackground(Color.yellow);    
    
    //Get an offscreen image object to draw on.  Then get
    // the graphics context for that offscreen image so
    // that it can be drawn on.
    offScreenImage = this.createImage(rawWidth,rawHeight);
    offScreenContext = offScreenImage.getGraphics();
    
    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor  
//=======================================================//
  
  //Override the update() method to eliminate unnecessary
  // erasing of the screen and the flashing caused by
  // such unnecessary erasing.  This requires screen
  // erasure to be handled in the overridden paint()
  // method.    
  public void update(Graphics g){
    paint(g);  
  }//end overridden update() method
  //=====================================================//
  
  //Override the paint method
  public void paint(Graphics g){
    if(doubleBuf){//use double buffering
      //Render (to the screen) the image previously 
      // created in the offscreen image
      g.drawImage(offScreenImage,inLeft,inTop,this);    
      
      //Scale and draw the next image in the offscreen 
      // area using the instance variables named newWidth 
      // and newHeight to establish the size.  It will be 
      // rendered to the screen the next time paint() is
      // invoked.  Note that the maximum drawing size is
      // limited to the size of the raw image.
      offScreenContext.clearRect(
                               0,0,rawWidth,rawHeight);
      offScreenContext.drawImage(
                     rawImage,0,0,newWidth,newHeight,this);
    }//end if                     
    else{ //don't use double buffering
      g.clearRect(inLeft,inTop,rawWidth,rawHeight);
      g.drawImage(
            rawImage,inLeft,inTop,newWidth,newHeight,this);
    }//end else
  }//end paint()
}//end Image04 class
//=======================================================//
