/*File Shapes02.java.java Copyright 1997, R.G.Baldwin
This program illustrates the use of the Canvas class and
several of the methods of the Graphics class.

The program creates two fake buttons that appear (on some
systems at least) to be green 3D button objects.

Note that the green 3D buttons are not constructed using 
the Button class or the draw3DRect() method of the Graphics
class.

When the program starts, two green fake buttons with 
captions of "Small" and "Large" along with a real Button 
with a caption of "Button" appear in a Frame object.  

The green buttons appears to protrude slightly from the 
surface of the Frame object in a manner similar to the
real Button object.

When you point to a green button with the mouse and 
press the left mouse button, the green button appears to
become depressed into the surface of the Frame object in
a manner similar to a real Button object.  

When you release the mouse button, the green button 
appears to pop back out of the surface of the Frame 
object. 

This is accomplished using a simple drawRect() method.
The draw3DRect() method is not used in this case.

The 3D effect is an artifact of the manner in which the 
rectangle is drawn onto an underlying Canvas object. The
reason that the 3D effect appears is explained in the 
comments.

When you click on a green button, some text is displayed
on the standard output device to confirm that the click 
occurred.

Some text is also displayed when you click on the real 
Button object.

It may be significant to note that the fake green buttons
are much more responsive than the real Button when running
under Win95 on a machine with a 133MHz Pentium.  This can
be demonstrated by clicking repeatedly on one or the
other as fast as you can click. The real Button appears to
miss some of the clicks while the fake green buttons 
appear to respond properly to every click.  At least the
fake green buttons responds to a much higher percentage of 
clicks than the real Button.

These results were produced using JDK 1.1.3, running under 
Windows 95.
*/
//=======================================================//
import java.awt.*;
import java.awt.event.*;

//=======================================================//
//This class is used to create a fake button object.

//Subclass Canvas to override the paint method in order
// to set the size and color of a Canvas object, to draw
// a rectangle which is partially on and partially off
// of the Canvas object, and to draw a caption on the
// Canvas object.
  
//The fact that the rectangle is only partially on the
// Canvas object causes the Canvas object to appear to 
// protrude out of the screen, or to be depressed into the 
// screen which produces the 3D effect. 

//The rectangle is offset either up and to the left 
// relative to the Canvas object or down and to the right.
// In either case, two lines on the border of the
// rectangle are lost.  The remaining two appear to be
// shadows and this causes the 3D effect.

class FakeButtonClass extends Canvas{
  boolean pushed = false;//indicates button pushed or not
  int width; //button width in pixels
  int height;//button height in pixels
  String caption;//caption for button
    
  public FakeButtonClass(//constructor
                     int width,int height,String caption){
    this.width = width;
    this.height = height;
    this.caption = caption;
    this.setBackground(Color.green);
    this.setSize(this.width,this.height);
  }//end constructor

  public void paint(Graphics g){
    //Determine offset and draw rectangle on Canvas object
    if(pushed) g.drawRect(1,1,width,height);
    else g.drawRect(-1,-1,width,height);
    
    //Draw the caption centered horizontally and slightly
    // above center vertically. For vertical placement, 
    // use one-fourth the sum of leading, ascent, and
    // descent parameters of the font to calculate the
    // baseline position for the characters.
    int fontHeight = g.getFontMetrics().getHeight();
    int stringWidth = 
                   g.getFontMetrics().stringWidth(caption);
    g.drawString(caption, 
          (width-stringWidth)/2,(height/2)+(fontHeight/4));
  }//end paint()
}//end class FakeButtonClass

//=======================================================//

class Shapes02 extends Frame{//controlling class
  public static void main(String[] args){
    //instantiate an object of this type
    new Shapes02();
  }//end main  
  
  public Shapes02(){//constructor
    this.setLayout(new FlowLayout());
    this.setTitle("Copyright 1997, R.G.Baldwin");
    this.setSize(300,150);

    //Instantiate two fake button objects of different
    // sizes and a real Button object
    FakeButtonClass firstFakeButton = 
                        new FakeButtonClass(40,20,"Small");
    FakeButtonClass secondFakeButton = 
                        new FakeButtonClass(80,40,"Large");
    Button myRealButton = new Button("Button");

    //Add the buttons to the Frame object
    this.add(firstFakeButton);
    this.add(myRealButton);
    this.add(secondFakeButton);
    
    this.setVisible(true);//make it all visible
  
    //Instantiate a mouse listener object and register it
    // to listen for mouse events on the two fake buttons
    MouseListenerClass myMouseListener = 
                                  new MouseListenerClass();
    firstFakeButton.addMouseListener(myMouseListener);
    secondFakeButton.addMouseListener(myMouseListener);
    
    //Instantiate and register an action listener object
    // on the real Button object.
    myRealButton.addActionListener(
                              new MyActionListenerClass());

    //Instantiate and register a Listener object which will
    // terminate the program when the user closes the 
    // Frame.
    WindowListenerClass myWindowListener = 
                                 new WindowListenerClass();
    this.addWindowListener(myWindowListener);  
  }//end constructor
}//end class Shapes02 definition
//=======================================================//

//This class is used to instantiate a listener object that
// listens for mouse events on the fake buttons and causes
// the visual rendering to switch between a protruding
// image and a "pushed" image. Also a message is displayed
// when the button is clicked.
class MouseListenerClass extends MouseAdapter{

  //Override the mousePressed() method
  public void mousePressed(MouseEvent e){
    //Set the "pushed" variable to true and repaint
    ((FakeButtonClass)e.getComponent()).pushed = true;
    e.getComponent().repaint();
  }//end mousePressed()

  //Override the mouseReleased() method
  public void mouseReleased(MouseEvent e){
    //Display a message
	  System.out.println("mouseReleased");
    
    //Set the "pushed" variable to false and repaint
    ((FakeButtonClass)e.getComponent()).pushed = false;
    e.getComponent().repaint();
  }//end mouseReleased()
}//end class MouseListenerClass
//=======================================================//

//This class is used to instantiate a listener object that
// listens for action events on the real button and 
// displays a message when it is clicked.
class MyActionListenerClass implements ActionListener{
  public void actionPerformed(ActionEvent e){
    System.out.println("actionPerformed");//announce
  }//end actionPerformed()
}//end class MyActionListenerClass

//=======================================================//

//The following listener is used to terminate the program 
// when the user closes the frame.
class WindowListenerClass extends WindowAdapter{
  public void windowClosing(WindowEvent e){
    System.exit(0);
  }//end windowClosing()
}//end class WindowListenerClass
//=======================================================//