/*File Graphics07.java
Copyright 1997, R.G.Baldwin

This program illustrates the drawing of all the shapes
available in JDK 1.1.3.

You will probably need to compile and run this program
to gain a good feel for how each shape is controlled by
its argument list.

This program was tested using JDK 1.1.3 under Win95.

**********************************************************/
import java.awt.*;
import java.awt.event.*;

class Graphics07 extends Frame{ //controlling class
  //Override the paint method
  public void paint(Graphics g){
    g.setColor(Color.red);//set the drawing color to red
    
    //Translate the 0,0 coordinate of the graphics context
    // to the upper left-hand corner of the client area of
    // the Frame object.
    g.translate(
               this.getInsets().left,this.getInsets().top);
    //Draw a simple line
    g.drawLine(0,0,50,50);
    
    //Create two arrays of coordinate data and draw a
    // polyline using that data
    int xData[] = {100,110,120,130,140,150}; 
    int yData[] = {0,25,37,43,47,50};
    g.drawPolyline(xData,yData,6);
    
    //Draw a rectangle
    g.drawRect(200,0,50,25);
    
    //Draw a filled rectangle
    g.fillRect(300,0,25,50);
    
    //Draw a rounded rectangle
    g.drawRoundRect(400,0,50,50,45,35);
    
    //Fill a rounded rectangle
    g.fillRoundRect(500,0,50,50,35,45);
    
    //Draw a 3D rectangle, raised, doesn't look very 3D, 
    // but a slight hint of 3D can be seen if drawn in
    // gray on on a white background.
    g.setColor(Color.gray);//draw the 3D stuff in gray
    g.draw3DRect(100,100,50,25,true);
    //Draw a 3D rectangle, depressed
    g.draw3DRect(200,100,50,25,false);
    
    //Fill a 3D rectangle, raised.  Can be made to look
    // pretty decent if drawn in gray on a gray background.
    // Otherwise, doesn't look very 3D.
    g.fillRect(275,75,75,100);//draw a gray background
    g.fill3DRect(300,100,25,50,true);
    //Fill a 3D rectangle, depressed, doesn't look very 3D
    g.fillRect(375,75,75,100);//draw a gray background
    g.fill3DRect(400,100,25,50,false);
    g.setColor(Color.red);//restore red color
    //Overall, the appearance of the 3DRect is not very
    // good because it is necessary to select special
    // colors and backgrounds to get the illusion of 3D.
    
    //Draw an oval, long axis on horizontal axis
    g.drawOval(0,200,50,25);
    //Fill an oval, long axos on vertical axis
    g.fillOval(100,200,25,50);
    //Fill an oval, which is a circle
    g.fillOval(200,200,50,50); 
    
    //Draw a 225-degree arc inside a bounding rectangle
    g.drawRect(300,200,25,50);
    g.drawArc(300,200,25,50,0,225); 
    
    //Fill a 225-degree arc inside a bounding rectangle
    g.drawRect(400,200,25,50);
    g.fillArc(400,200,25,50,0,225);
    
    //Draw a polygon using array data as parameters
    int xxData[] = {0,10,20,30,40,50}; 
    int yyData[] = {300,325,337,343,347,350};
    g.drawPolygon(xxData,yyData,6);
    
    //Fill a polygon using array data as parameters
    int xxxData[] = {100,110,120,130,140,150}; 
    int yyyData[] = {300,325,337,343,347,350};
    g.fillPolygon(xxxData,yyyData,6);
      
  }//end paint()

  public Graphics07(){//constructor
    this.setTitle(
             "Shape Samples,Copyright 1997, R.G.Baldwin");
    this.setSize(600,400);
    this.setVisible(true);

    //Anonymous inner-class listener to terminate program
    this.addWindowListener(
      new WindowAdapter(){//anonymous class definition
        public void windowClosing(WindowEvent e){
          System.exit(0);//terminate the program
        }//end windowClosing()
      }//end WindowAdapter
    );//end addWindowListener
  }//end constructor
  
  public static void main(String[] args){
    new Graphics07();//instantiate this object
  }//end main
}//end Graphics07 class
//=======================================================//