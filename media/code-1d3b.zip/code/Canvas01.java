/*File Canvas01.java Copyright 1997, R.G.Baldwin
Illustrates the use of the Canvas class.

Also illustrates the ability to instantiate listener
objects that can manipulate the source objects on which
they are registered without the requirement to pass
references to those source objects when the listener
objects are instantiated.

No parameterized constructors are used in the
instantiation of listener objects in this program.

When the program first appears on the screen, four non-
functional buttons and a green Canvas object appear in a
Frame object.  The objects are separated by horizontal and
vertical gaps of thirty pixels.

The four buttons are placed at the borders of the Frame
object using the BorderLayout manager.  The Canvas object
is placed in the Center of the Frame object.

When you click on the green Canvas object, the coordinates
of the mouse pointer are displayed.

Clicking in the gaps or clicking on the buttons has no
effect on the program.

Clicking on the close button on the Frame object 
terminates the program and returns control to the 
operating system.

These results were produced using JDK 1.1.3, running under 
Windows 95.
*/
//=======================================================//
import java.awt.*;
import java.awt.event.*;

//=======================================================//

//Subclass Canvas in order to override the paint method
// and to make it green when instantiated.
class MyCanvas extends Canvas{
  int clickX;
  int clickY;
  
  public MyCanvas(){//constructor
    this.setBackground(Color.green);
  }//end constructor
  
  //Override the paint() method.
  public void paint(Graphics g){
    g.drawString(
              "" + clickX + ", " + clickY, clickX, clickY);
  }//end paint()
}//end class MyCanvas
//=======================================================//

class Canvas01 extends Frame{//controlling class
  public static void main(String[] args){
    //instantiate an object of this type
    new Canvas01();
  }//end main  
  
  public Canvas01(){//constructor
  
    //Create a border layout with gaps.
    BorderLayout myLayout = new BorderLayout();
    myLayout.setVgap(30);
    myLayout.setHgap(30);
    
    this.setLayout(myLayout);//Apply layout to the Frame
    this.setTitle("Copyright 1997, R.G.Baldwin");
    this.setSize(300,300);
    
    //Instantiate a green customized Canvas object
    MyCanvas myCanvasObject = new MyCanvas();
 
    //Add the MyCanvas object to the center of the 
    // Frame object.
    this.add(myCanvasObject,"Center");
    
    //Add four nonfunctional buttons to the borders
    // of the Frame object
    
    this.add(new Button("North"),"North");    
    this.add(new Button("South"),"South");
    this.add(new Button("East"),"East");
    this.add(new Button("West"),"West");
    
    this.setVisible(true);//make it all visible
     
    //Instantiate and register Listener object which will 
    // terminate the program when the user closes the 
    // Frame.
    WProc1 winProcCmd1 = new WProc1();
    this.addWindowListener(winProcCmd1);
    
    //Instantiate and register Listener object which will 
    // process mouse events to determine and display the 
    // coordinates when the user presses the mouse button
    // on the MyCanvas object.
    
    // Note that the Listener object is instantiated
    // anonymously and no reference to the MyCanvas object
    // is passed to the constructor for the Listener 
    // object.
    
    myCanvasObject.addMouseListener(new MouseProc());    
  
  }//end constructor
}//end class Canvas01 definition
//=======================================================//

//This listener class monitors for mouse presses and 
// displays the coordinates of the mouse pointer when the 
// mouse is pressed on the object for which it is
// registered.
class MouseProc extends MouseAdapter{
  //Override the mousePressed method
  public void mousePressed(MouseEvent e){
    //Get x and y coordinates of the mouse pointer and
    // store in the instance variables of the MyCanvas
    // object.  Note the requirement to cast the component
    // to the type of MyCanvas in order to access the 
    // instance variables.
    ((MyCanvas)e.getComponent()).clickX = e.getX();
    ((MyCanvas)e.getComponent()).clickY = e.getY();
    //display coordinate information    
    e.getComponent().repaint();
    
  }//end mousePressed()
}//end class MouseProc
//=======================================================//

//The following listener is used to terminate the program 
// when the user closes the frame.
class WProc1 extends WindowAdapter{
  public void windowClosing(WindowEvent e){
    System.exit(0);
  }//end windowClosing()
}//end class WProc1
//=======================================================//